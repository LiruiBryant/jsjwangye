<!doctype html>
<html>
<head>

<meta charset="utf-8" name="viewport" content="width=device-width">
<title>计算机学院-学生工作</title>
<style type="text/css">

.time{
	color:#999 !important;
	margin:0px !important;
	font-size:14px !important;
	padding:0px !important;}
div{
	
	padding-bottom:5px;
	padding-top:5px;}
a{ 
	text-decoration:none;
	font-weight:normal !important;
	
	color:#333 !important;
	}
	.header1{
		color:#FFF !important;
		background-color:#06C !important;}
.hengxian{
	
	border-bottom:solid 1px rgba(124,76,164, 0.4);
	}
.yejiao{
	
	font-weight:normal !important;
	font-size:10px; !important}
.yemei{
	
	 margin-top:5px !important;}


</style>
<link href="http://code.jquery.com/mobile/1.4.4/jquery.mobile-1.4.4.min.css" rel="stylesheet" type="text/css"/>
<script src="http://code.jquery.com/jquery-1.11.0.min.js" type="text/javascript"></script>
<script src="http://code.jquery.com/mobile/1.4.4/jquery.mobile-1.4.4.min.js" type="text/javascript"></script>
</head>

<body>  


<h1 align="center">学生工作</h1>


   
    <?php
$id=2;
$id = $_GET["p"];
$strarray=array();
$lianjiearray=array();

//取得指定位址的內容，並储存至text
$text=file_get_contents('http://cs.cumt.edu.cn/list.php?classname=学生工作&p='.$id.'');

//去除換行及空白字元（序列化內容才需使用）
$text=str_replace(array("\r","\n","\t","\s"), '', $text); 

//取出div标签且id為PostContent的內容，並储存至阵列match
//preg_match('/<div[^>]*class="texthidden"[^>]*>(.*?) <\/div>/si',$text,$match);
//preg_match_all('/title="[^x00-xff]*"/si',$text,$a);
//
//preg_match_all('/alt="[^x00-xff]*"/si',$text,$aa);

//preg_match_all('/<div[^>]*class="texthiddendiv"[^>]*>(.*?)<img [^>]*\/>(.*?)<a[^.]*[^x00-xff]*[^.]*>[^x00-xff]*<\/a><\/div>/si',$text,$aaa);

preg_match_all('/<a[^>]*[^x00-xff]*[^>]*[^x00-xff]*[^>]*>(.*?)<\/a>/si',$text,$aaa);

//印出match[0
//print($match[0]);
//preg_match_all('/target="_self"[^>]*title="[^x00-xff]*"/si',$text,$aaa);

//$arr=$a[0];
//for ($i= 0;$i< count($arr); $i++){
//$str= $arr[$i];
//echo "the number is $str.<br />";
//}



$arr1=$aaa[0];
for ($i= 0;$i< count($arr1); $i++){
$str= $arr1[$i];

    preg_match_all('/(mce\_href\=list\.php\?classname\=[^x00-xff]*\&p\=\d{0,3})|（http\:\/\/cs\.cumt\.edu\.cn\/studentworknew\/read\.php\?id=\d{0,3}[^\"]*）|(read\.php\?id=\d{0,4})|(http\:\/\/www\.cumt\.edu\.cn\/[^\"]*[^x00-xff\"]*)/si',$str,$lianjie);

$lianjie1=$lianjie[0];

for ($j= 0;$j< count($lianjie1); $j++){

$strlianjie=$lianjie1[$j];

if($i<35||$i==71){
    
	continue;} 
	
    
    else{

$lianjiearray[$i]=$strlianjie;

        //   print_r($strlianjie);


    }
    
    //echo " <br />";
}



$str=preg_replace('/[a-zA-Z0-9\_\-\.\"\=\<\>\:\/\?\;\&&\%%]+/', "", $str);
    $len=strlen($str)/2;
    $str = substr($str,$len-16);
//$str=preg_replace('/^(<div)[\n.]*[^x00-xff]*[\n.]*(\")$>/',"", $str);
//preg_match_all("/[\x{4e00}-\x{9fa5}]+/u",$str,$match);
//preg_match_all("/[\x{4e00}-\x{9fa5}]+/u",$str,$str3);
//preg_match_all('/^(title)="[^.]*[^x00-xff]*[^.]*[^x00-xff]*[^.]*"(>)$/si',$str,$str3);
if($i<41||$i>50){
	continue;}
	else{
$strarray[$i]=$str;

        // print_r($str);

    }

    //echo " <br />";
}

//print_r($arr[1]);

/*foreach($strarray as $a){
echo $a;}
foreach($lianjiearray as $l){
echo $l;}
*/









                                          
      for ($i= 41;$i<51; $i++){
$str=$lianjiearray[$i];   
$str2= $strarray[$i];
          // echo $str;
          //echo $str2;
echo'<div class="hengxian">
   		<a  href=http://3.lirui1994.sinaapp.com/b.php?id='.$str.'target="'.' >'.$str2.'</a> <p class="time"></p>
         </div>';
      }
    
echo '当前第'.$id.'/19页 [首页] [上一页] ';
    for($i=1;$i<20;$i++)
        {
        if($i == $id){
        echo '  

       [<span style="color:red;font-weight:bold;" mce_style="color:red;font-weight:bold;">'.$i.'</span>]';
        }else {
        echo '     [<a href = %E5%AD%A6%E7%94%9F%E5%B7%A5%E4%BD%9C.php?classname=学生工作&p='.$i.' mce_href=%E5%AD%A6%E7%94%9F%E5%B7%A5%E4%BD%9C.php?classname=学生工作&p='.$i.'>'.$i.'</a> ]';
        }}
/*  [<a href=list.php?classname=学生工作&p=2 mce_href=list.php?classname=学生工作&p=2>2</a>]
        [<a href=list.php?classname=学生工作&p=3 mce_href=list.php?classname=学生工作&p=3>3</a>]
        [<a href=list.php?classname=学生工作&p=4 mce_href=list.php?classname=学生工作&p=4>4</a>]
        [<a href=list.php?classname=学生工作&p=5 mce_href=list.php?classname=学生工作&p=5>5</a>]
        [<a href=list.php?classname=学生工作&p=6 mce_href=list.php?classname=学生工作&p=6>6</a>]
        [<a href=list.php?classname=学生工作&p=7 mce_href=list.php?classname=学生工作&p=7>7</a>]
        [<a href=list.php?classname=学生工作&p=8 mce_href=list.php?classname=学生工作&p=8>8</a>]
        [<a href=list.php?classname=学生工作&p=9 mce_href=list.php?classname=学生工作&p=9>9</a>]
        [<a href=list.php?classname=学生工作&p=10 mce_href=list.php?classname=学生工作&p=10>10</a>]
        [<a href=list.php?classname=学生工作&p=11 mce_href=list.php?classname=学生工作&p=11>11</a>]
        [<a href=list.php?classname=学生工作&p=12 mce_href=list.php?classname=学生工作&p=12>12</a>]
        [<a href=list.php?classname=学生工作&p=13 mce_href=list.php?classname=学生工作&p=13>13</a>]
        [<a href=list.php?classname=学生工作&p=14 mce_href=list.php?classname=学生工作&p=14>14</a>]
        [<a href=list.php?classname=学生工作&p=15 mce_href=list.php?classname=学生工作&p=15>15</a>]
        [<a href=list.php?classname=学生工作&p=16 mce_href=list.php?classname=学生工作&p=16>16</a>]
        [<a href=list.php?classname=学生工作&p=17 mce_href=list.php?classname=学生工作&p=17>17</a>]
        [<a href=list.php?classname=学生工作&p=18 mce_href=list.php?classname=学生工作&p=18>18</a>]
        [<a href=list.php?classname=学生工作&p=19 mce_href=list.php?classname=学生工作&p=19>19</a>]
        [<a href=list.php?classname=学生工作&p=2 mce_href=list.php?classname=学生工作&p=2>下一页</a>]
        [<a href=list.php?classname=学生工作&p=19 mce_href=list.php?classname=学生工作&p=19>尾页</a>]   
    
    */
    
    ?>
   










</body>
</html>
